import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ApostaTeste {

    @BeforeEach
    void preparaCampeonato(){

    }

}
